import { useState, useEffect } from "react"
import { db } from "../database/db.js"
import "./Products.css"

const Products = () => {
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [filter, setFilter] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [showStickyNav, setShowStickyNav] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  
  // Comment form state
  const [commentForm, setCommentForm] = useState({
    reviewer_name: "",
    rating: 5,
    comment: ""
  })
  const [isSubmittingComment, setIsSubmittingComment] = useState(false)

  useEffect(() => {
    loadProducts()
  }, [])

  useEffect(() => {
    filterProducts()
  }, [products, filter, searchTerm])

  useEffect(() => {
    const handleScroll = () => {
      const headerHeight = window.innerHeight
      const scrollY = window.scrollY
      setShowStickyNav(scrollY > headerHeight - 100)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const observerOptions = {
      threshold: 0.3,
      rootMargin: "0px 0px -100px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible")
        }
      })
    }, observerOptions)

    const elements = document.querySelectorAll(".scroll-animate")
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [filteredProducts])

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (showModal) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [showModal])

  const loadProducts = () => {
    try {
      const allProducts = db.getProducts().map((product) => ({
        ...product,
        features: db.getFeaturesByProduct(product.id) || [],
        specifications: db.getSpecificationsByProduct(product.id) || [],
        images: db.getImagesByProduct(product.id) || [],
        reviews: db.getReviewsByProduct(product.id) || [],
        mainImage: db.getMainImage(product.id) || "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg",
      }))
      setProducts(allProducts)
    } catch (error) {
      console.error("Error loading products:", error)
      setProducts([])
    }
  }

  const filterProducts = () => {
    let filtered = products

    if (filter === "featured") {
      filtered = filtered.filter((product) => product.is_featured)
    }

    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    setFilteredProducts(filtered)
  }

  const calculateAverageRating = (reviews) => {
    if (!reviews || reviews.length === 0) return 0
    const sum = reviews.reduce((acc, review) => acc + (review.rating || 0), 0)
    return (sum / reviews.length).toFixed(1)
  }

  const openProductModal = (product) => {
    setSelectedProduct(product)
    setActiveImageIndex(0)
    setShowModal(true)
    // Reset comment form
    setCommentForm({
      reviewer_name: "",
      rating: 5,
      comment: ""
    })
  }

  const closeModal = () => {
    setShowModal(false)
    setSelectedProduct(null)
    setActiveImageIndex(0)
    setCommentForm({
      reviewer_name: "",
      rating: 5,
      comment: ""
    })
  }

  const nextImage = () => {
    if (selectedProduct && selectedProduct.images && selectedProduct.images.length > 1) {
      setActiveImageIndex((prev) => 
        prev === selectedProduct.images.length - 1 ? 0 : prev + 1
      )
    }
  }

  const prevImage = () => {
    if (selectedProduct && selectedProduct.images && selectedProduct.images.length > 1) {
      setActiveImageIndex((prev) => 
        prev === 0 ? selectedProduct.images.length - 1 : prev - 1
      )
    }
  }

  const getReviewerInitial = (reviewerName) => {
    if (!reviewerName || typeof reviewerName !== 'string') {
      return '?'
    }
    return reviewerName.charAt(0).toUpperCase()
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'تاریخ نامشخص'
    try {
      return new Date(dateString).toLocaleDateString('fa-IR')
    } catch (error) {
      return 'تاریخ نامشخص'
    }
  }

  const getCurrentImage = () => {
    if (!selectedProduct || !selectedProduct.images || selectedProduct.images.length === 0) {
      return selectedProduct?.mainImage || "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
    }
    
    const currentImage = selectedProduct.images[activeImageIndex]
    return currentImage?.image || selectedProduct.mainImage || "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
  }

  // Comment submission handler
  const handleCommentSubmit = async (e) => {
    e.preventDefault()
    
    if (!commentForm.reviewer_name.trim() || !commentForm.comment.trim()) {
      alert('لطفاً نام و نظر خود را وارد کنید')
      return
    }

    setIsSubmittingComment(true)
    
    try {
      // Create new review
      const newReview = {
        product_id: selectedProduct.id,
        reviewer_name: commentForm.reviewer_name.trim(),
        rating: commentForm.rating,
        comment: commentForm.comment.trim(),
        approved: true // Auto-approve for demo
      }
      
      db.createReview(newReview)
      
      // Reload the selected product with updated reviews
      const updatedProduct = {
        ...selectedProduct,
        reviews: db.getReviewsByProduct(selectedProduct.id)
      }
      setSelectedProduct(updatedProduct)
      
      // Reset form
      setCommentForm({
        reviewer_name: "",
        rating: 5,
        comment: ""
      })
      
      // Reload all products to update the main list
      loadProducts()
      
      alert('نظر شما با موفقیت ثبت شد!')
      
    } catch (error) {
      console.error('Error submitting comment:', error)
      alert('خطا در ثبت نظر. لطفاً دوباره تلاش کنید.')
    } finally {
      setIsSubmittingComment(false)
    }
  }

  const handleCommentFormChange = (field, value) => {
    setCommentForm(prev => ({
      ...prev,
      [field]: value
    }))
  }

  // Star Rating Component
  const StarRating = ({ rating, onRatingChange, readonly = false, size = "medium" }) => {
    const [hoverRating, setHoverRating] = useState(0)
    
    const handleStarClick = (starValue) => {
      if (!readonly && onRatingChange) {
        onRatingChange(starValue)
      }
    }
    
    const handleStarHover = (starValue) => {
      if (!readonly) {
        setHoverRating(starValue)
      }
    }
    
    const handleStarLeave = () => {
      if (!readonly) {
        setHoverRating(0)
      }
    }
    
    return (
      <div className={`star-rating ${size} ${readonly ? 'readonly' : 'interactive'}`}>
        {[1, 2, 3, 4, 5].map((starValue) => (
          <button
            key={starValue}
            type="button"
            className={`star-button ${
              starValue <= (hoverRating || rating) ? 'filled' : 'empty'
            }`}
            onClick={() => handleStarClick(starValue)}
            onMouseEnter={() => handleStarHover(starValue)}
            onMouseLeave={handleStarLeave}
            disabled={readonly}
            aria-label={`${starValue} ستاره`}
          >
            <svg viewBox="0 0 24 24" className="star-icon">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
          </button>
        ))}
      </div>
    )
  }

  return (
    <div className="persian-products">
      {/* Compact Sticky Navigation */}
      <nav className={`compact-sticky-nav ${showStickyNav ? 'visible' : ''}`}>
        <div className="compact-nav-content">
          <div className="compact-logo desktop-only">
            <div className="logo-icon">🎭</div>
          </div>
          
          <div className="compact-main-content">
            <div className="compact-search">
              <input
                type="text"
                placeholder="جستجو..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="compact-search-field"
              />
              <div className="compact-search-icon">🔍</div>
            </div>
            
            <div className="compact-filters">
              <button 
                className={`compact-filter-btn ${filter === "all" ? "active" : ""}`}
                onClick={() => setFilter("all")}
              >
                همه
              </button>
              <button 
                className={`compact-filter-btn ${filter === "featured" ? "active" : ""}`}
                onClick={() => setFilter("featured")}
              >
                ویژه
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Header Section */}
      <header className="page-header">
        <div className="header-background">
          <div className="animated-bg">
            <div className="floating-shapes">
              <div className="shape shape-1"></div>
              <div className="shape shape-2"></div>
              <div className="shape shape-3"></div>
              <div className="shape shape-4"></div>
              <div className="shape shape-5"></div>
              <div className="shape shape-6"></div>
            </div>
            <div className="grid-overlay"></div>
          </div>
        </div>
        
        <div className="header-content">
          <div className="hero-section">
            <div className="title-container">
              <h1 className="main-title">
                <span className="title-word" data-text="محصولات">محصولات</span>
              </h1>
            </div>
            
            <p className="main-subtitle">
              <span className="subtitle-line">انواع محصولات شهربازی</span>
            </p>
          </div>
          
          <div className="header-controls">
            <div className="search-container">
              <div className="search-box">
                <input
                  type="text"
                  placeholder="دنبال چه محصولی می‌گردید؟"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-field"
                />
                <div className="search-btn">
                  <div className="search-icon">🔍</div>
                </div>
              </div>
            </div>
            
            <div className="filter-section">
              <div className="filter-label">دسته‌بندی:</div>
              <div className="filter-buttons">
                <button 
                  className={`filter-btn ${filter === "all" ? "active" : ""}`}
                  onClick={() => setFilter("all")}
                >
                  <span className="btn-bg"></span>
                  <span className="btn-text">همه محصولات</span>
                </button>
                <button 
                  className={`filter-btn ${filter === "featured" ? "active" : ""}`}
                  onClick={() => setFilter("featured")}
                >
                  <span className="btn-bg"></span>
                  <span className="btn-text">محصولات ویژه</span>
                  <span className="btn-icon">⭐</span>
                </button>
              </div>
            </div>
          </div>
          
          <div className="scroll-indicator">
            <div className="scroll-text">برای مشاهده محصولات اسکرول کنید</div>
            <div className="scroll-arrow">
              <div className="arrow-line"></div>
              <div className="arrow-head"></div>
            </div>
          </div>
        </div>
      </header>

      {/* Product Sections */}
      {filteredProducts.map((product, index) => (
        <section key={product.id} className="product-section scroll-animate">
          {/* Background Video/Image */}
          <div className="section-background">
            {product.background_video ? (
              <video 
                autoPlay 
                muted 
                loop 
                playsInline 
                className="bg-video"
              >
                <source src={product.background_video} type="video/mp4" />
              </video>
            ) : (
              <img 
                src={product.mainImage || "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"} 
                alt={product.title || 'محصول'}
                className="bg-image"
              />
            )}
            <div className="dark-overlay"></div>
          </div>

          {/* Product Content */}
          <div className="section-content">
            <div className="product-info">
              {product.is_featured && (
                <div className="featured-tag">
                  <span className="star-icon">⭐</span>
                  <span>محصول ویژه</span>
                </div>
              )}

              <h2 className="product-title">{product.title || 'محصول بدون نام'}</h2>
              
              <div className="rating-section">
                <StarRating 
                  rating={Math.floor(calculateAverageRating(product.reviews))} 
                  readonly={true}
                  size="small"
                />
                <span className="rating-info">
                  {calculateAverageRating(product.reviews)} ({(product.reviews || []).length} نظر)
                </span>
              </div>

              <p className="product-desc">{product.description || 'توضیحی برای این محصول موجود نیست.'}</p>

              {product.features && product.features.length > 0 && (
                <div className="features-preview">
                  <h4>ویژگی‌های کلیدی:</h4>
                  <div className="features-list">
                    {product.features.slice(0, 4).map((feature, idx) => (
                      <div key={idx} className="feature-item">
                        <span className="check-icon">✓</span>
                        <span>{feature.value || 'ویژگی نامشخص'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button 
                type="button"
                className="btn details-btn"
                onClick={() => openProductModal(product)}
              >
                <span className="details-btn-text">مشاهده جزئیات</span>
                <div id="container-stars">
                  <div id="stars"></div>
                </div>
                <div id="glow">
                  <div className="circle"></div>
                  <div className="circle"></div>
                </div>
              </button>
            </div>
          </div>
        </section>
      ))}

      {/* Empty State */}
      {filteredProducts.length === 0 && (
        <section className="empty-state scroll-animate">
          <div className="empty-content">
            <div className="empty-icon">🎭</div>
            <h3>محصولی یافت نشد</h3>
            <p>لطفاً جستجوی خود را تغییر دهید یا فیلترها را بررسی کنید</p>
            <button 
              className="reset-btn"
              onClick={() => {
                setSearchTerm("")
                setFilter("all")
              }}
            >
              نمایش همه محصولات
            </button>
          </div>
        </section>
      )}

      {/* Redesigned Product Modal */}
      {showModal && selectedProduct && (
        <div className="modal-backdrop" onClick={closeModal}>
          <div className="product-modal-container" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="modal-header-new">
              <button className="modal-close-btn" onClick={closeModal}>
                <span className="close-icon">×</span>
              </button>
              <div className="modal-title-section">
                <h2 className="modal-product-title">{selectedProduct.title || 'محصول بدون نام'}</h2>
                <div className="modal-rating-quick">
                  <StarRating 
                    rating={Math.floor(calculateAverageRating(selectedProduct.reviews))} 
                    readonly={true}
                    size="small"
                  />
                  <span className="rating-quick-text">
                    {calculateAverageRating(selectedProduct.reviews)}
                  </span>
                </div>
              </div>
            </div>

            {/* Modal Content */}
            <div className="modal-body-new">
              {/* Image Gallery Section */}
              <div className="modal-gallery-section">
                <div className="main-image-container">
                  <img 
                    src={getCurrentImage()} 
                    alt={selectedProduct.title || 'محصول'}
                    className="modal-main-image-new"
                  />
                  {selectedProduct.images && selectedProduct.images.length > 1 && (
                    <>
                      <button className="gallery-nav-btn prev-btn" onClick={prevImage}>
                        <span>‹</span>
                      </button>
                      <button className="gallery-nav-btn next-btn" onClick={nextImage}>
                        <span>›</span>
                      </button>
                    </>
                  )}
                  <div className="image-counter">
                    {activeImageIndex + 1} / {(selectedProduct.images || []).length || 1}
                  </div>
                </div>
                
                {selectedProduct.images && selectedProduct.images.length > 1 && (
                  <div className="thumbnail-gallery">
                    {selectedProduct.images.map((image, idx) => (
                      <button
                        key={idx}
                        className={`thumbnail-btn ${idx === activeImageIndex ? 'active' : ''}`}
                        onClick={() => setActiveImageIndex(idx)}
                      >
                        <img 
                          src={image.image || "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"} 
                          alt={`${selectedProduct.title || 'محصول'} ${idx + 1}`}
                          className="thumbnail-image"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Info Tabs */}
              <div className="modal-tabs-section">
                <div className="tab-content-container">
                  {/* Description */}
                  <div className="tab-panel active">
                    <div className="panel-header">
                      <h3 className="panel-title">
                        <span className="panel-icon">📝</span>
                        توضیحات
                      </h3>
                    </div>
                    <div className="panel-content">
                      <p className="product-description-full">
                        {selectedProduct.description || 'توضیحی برای این محصول موجود نیست.'}
                      </p>
                    </div>
                  </div>

                  {/* Features */}
                  {selectedProduct.features && selectedProduct.features.length > 0 && (
                    <div className="tab-panel">
                      <div className="panel-header">
                        <h3 className="panel-title">
                          <span className="panel-icon">⚡</span>
                          ویژگی‌ها
                        </h3>
                      </div>
                      <div className="panel-content">
                        <div className="features-grid-new">
                          {selectedProduct.features.map((feature, idx) => (
                            <div key={idx} className="feature-card-new">
                              <div className="feature-icon-new">✨</div>
                              <span className="feature-text-new">{feature.value || 'ویژگی نامشخص'}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Specifications */}
                  {selectedProduct.specifications && selectedProduct.specifications.length > 0 && (
                    <div className="tab-panel">
                      <div className="panel-header">
                        <h3 className="panel-title">
                          <span className="panel-icon">⚙️</span>
                          مشخصات فنی
                        </h3>
                      </div>
                      <div className="panel-content">
                        <div className="specs-grid-new">
                          {selectedProduct.specifications.map((spec, idx) => (
                            <div key={idx} className="spec-card-new">
                              <div className="spec-label">{spec.name || 'مشخصه نامشخص'}</div>
                              <div className="spec-value">{spec.value || 'مقدار نامشخص'}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Reviews */}
                  <div className="tab-panel">
                    <div className="panel-header">
                      <h3 className="panel-title">
                        <span className="panel-icon">💬</span>
                        نظرات کاربران
                      </h3>
                      {selectedProduct.reviews && selectedProduct.reviews.length > 0 && (
                        <div className="reviews-summary">
                          <div className="avg-rating-large">
                            {calculateAverageRating(selectedProduct.reviews)}
                          </div>
                          <div className="rating-breakdown">
                            <StarRating 
                              rating={Math.floor(calculateAverageRating(selectedProduct.reviews))} 
                              readonly={true}
                              size="large"
                            />
                            <div className="total-reviews">
                              {selectedProduct.reviews.length} نظر
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="panel-content">
                      {/* Add Comment Form */}
                      <div className="comment-form-section">
                        <h4 className="comment-form-title">نظر خود را بنویسید</h4>
                        <form onSubmit={handleCommentSubmit} className="comment-form">
                          <div className="form-row">
                            <div className="form-group">
                              <label htmlFor="reviewer_name">نام شما:</label>
                              <input
                                type="text"
                                id="reviewer_name"
                                value={commentForm.reviewer_name}
                                onChange={(e) => handleCommentFormChange('reviewer_name', e.target.value)}
                                placeholder="نام خود را وارد کنید"
                                required
                                disabled={isSubmittingComment}
                              />
                            </div>
                            <div className="form-group">
                              <label htmlFor="rating">امتیاز:</label>
                              <StarRating 
                                rating={commentForm.rating}
                                onRatingChange={(rating) => handleCommentFormChange('rating', rating)}
                                readonly={isSubmittingComment}
                                size="medium"
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="comment">نظر شما:</label>
                            <textarea
                              id="comment"
                              value={commentForm.comment}
                              onChange={(e) => handleCommentFormChange('comment', e.target.value)}
                              placeholder="نظر خود را در مورد این محصول بنویسید..."
                              rows={4}
                              required
                              disabled={isSubmittingComment}
                            />
                          </div>
                          <button 
                            type="submit" 
                            className="submit-comment-btn"
                            disabled={isSubmittingComment}
                          >
                            {isSubmittingComment ? 'در حال ارسال...' : 'ثبت نظر'}
                          </button>
                        </form>
                      </div>

                      {/* Existing Reviews */}
                      {selectedProduct.reviews && selectedProduct.reviews.length > 0 ? (
                        <div className="reviews-list-new">
                          <h4 className="reviews-list-title">نظرات ثبت شده</h4>
                          {selectedProduct.reviews.map((review, idx) => (
                            <div key={idx} className="review-card-new">
                              <div className="review-header-new">
                                <div className="reviewer-info">
                                  <div className="reviewer-avatar">
                                    {getReviewerInitial(review.reviewer_name)}
                                  </div>
                                  <div className="reviewer-details">
                                    <div className="reviewer-name-new">
                                      {review.reviewer_name || 'کاربر ناشناس'}
                                    </div>
                                    <div className="review-date">
                                      {formatDate(review.created_at)}
                                    </div>
                                  </div>
                                </div>
                                <div className="review-rating-new">
                                  <StarRating 
                                    rating={review.rating || 0}
                                    readonly={true}
                                    size="small"
                                  />
                                </div>
                              </div>
                              <p className="review-comment-new">
                                {review.comment || 'نظری ثبت نشده است.'}
                              </p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="no-reviews">
                          <p>هنوز نظری برای این محصول ثبت نشده است. اولین نفری باشید که نظر می‌دهد!</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Products