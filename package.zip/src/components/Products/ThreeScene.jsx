import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';

const ThreeScene = ({ isHero = false, productData = null }) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const animationIdRef = useRef(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    mountRef.current.appendChild(renderer.domElement);

    sceneRef.current = scene;
    rendererRef.current = renderer;
    cameraRef.current = camera;

    if (isHero) {
      createHeroScene(scene, camera);
    } else if (productData) {
      createProductScene(scene, camera, productData);
    }

    // Animation loop
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [isHero, productData]);

  const createHeroScene = (scene, camera) => {
    // Ambient lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    // Main directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(50, 50, 50);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    // Point lights for atmosphere
    const pointLight1 = new THREE.PointLight(0xffdd59, 2, 100);
    pointLight1.position.set(-30, 20, 30);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x13c8ff, 1.5, 100);
    pointLight2.position.set(30, -20, -30);
    scene.add(pointLight2);

    // Create floating geometric shapes
    const shapes = [];
    const geometries = [
      new THREE.BoxGeometry(2, 2, 2),
      new THREE.SphereGeometry(1.5, 32, 32),
      new THREE.ConeGeometry(1, 3, 8),
      new THREE.TorusGeometry(1.5, 0.5, 16, 100),
      new THREE.OctahedronGeometry(1.8),
    ];

    const materials = [
      new THREE.MeshPhysicalMaterial({ 
        color: 0xffdd59, 
        metalness: 0.7, 
        roughness: 0.2,
        transmission: 0.1,
        thickness: 0.5
      }),
      new THREE.MeshPhysicalMaterial({ 
        color: 0x13c8ff, 
        metalness: 0.8, 
        roughness: 0.1,
        transmission: 0.2,
        thickness: 0.3
      }),
      new THREE.MeshPhysicalMaterial({ 
        color: 0xff6b6b, 
        metalness: 0.6, 
        roughness: 0.3,
        emissive: 0x330000,
        emissiveIntensity: 0.1
      }),
    ];

    for (let i = 0; i < 15; i++) {
      const geometry = geometries[Math.floor(Math.random() * geometries.length)];
      const material = materials[Math.floor(Math.random() * materials.length)];
      const mesh = new THREE.Mesh(geometry, material);
      
      mesh.position.set(
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 60,
        (Math.random() - 0.5) * 100
      );
      
      mesh.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );

      mesh.castShadow = true;
      mesh.receiveShadow = true;
      
      scene.add(mesh);
      shapes.push(mesh);

      // Animate each shape
      gsap.to(mesh.rotation, {
        x: mesh.rotation.x + Math.PI * 2,
        y: mesh.rotation.y + Math.PI * 2,
        z: mesh.rotation.z + Math.PI * 2,
        duration: 10 + Math.random() * 10,
        repeat: -1,
        ease: "none"
      });

      gsap.to(mesh.position, {
        y: mesh.position.y + (Math.random() - 0.5) * 20,
        duration: 3 + Math.random() * 4,
        repeat: -1,
        yoyo: true,
        ease: "power2.inOut"
      });
    }

    // Create particle system
    const particleCount = 1000;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 200;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 200;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 200;

      const color = new THREE.Color();
      color.setHSL(Math.random() * 0.2 + 0.1, 0.7, 0.5);
      particleColors[i * 3] = color.r;
      particleColors[i * 3 + 1] = color.g;
      particleColors[i * 3 + 2] = color.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 0.5,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // Animate particles
    gsap.to(particles.rotation, {
      y: Math.PI * 2,
      duration: 60,
      repeat: -1,
      ease: "none"
    });

    // Camera position and animation
    camera.position.set(0, 0, 50);
    
    // Smooth camera movement
    gsap.to(camera.position, {
      x: 10,
      y: 5,
      duration: 20,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    gsap.to(camera.rotation, {
      z: 0.1,
      duration: 15,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });
  };

  const createProductScene = (scene, camera, productData) => {
    // Lighting setup
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.2);
    directionalLight.position.set(30, 30, 30);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Create product representation based on type
    const productMesh = createProductMesh(productData);
    scene.add(productMesh);

    // Add environmental elements
    const ringGeometry = new THREE.RingGeometry(8, 12, 32);
    const ringMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffdd59,
      transparent: true,
      opacity: 0.3,
      metalness: 0.8,
      roughness: 0.2
    });
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -5;
    scene.add(ring);

    // Animate product
    gsap.to(productMesh.rotation, {
      y: Math.PI * 2,
      duration: 12,
      repeat: -1,
      ease: "none"
    });

    gsap.to(productMesh.position, {
      y: productMesh.position.y + 2,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // Camera setup
    camera.position.set(0, 5, 25);
    camera.lookAt(0, 0, 0);
  };

  const createProductMesh = (productData) => {
    const group = new THREE.Group();

    // Main product shape (carousel-like structure)
    const mainGeometry = new THREE.CylinderGeometry(6, 6, 2, 12);
    const mainMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x13c8ff,
      metalness: 0.7,
      roughness: 0.3,
      transmission: 0.1
    });
    const mainMesh = new THREE.Mesh(mainGeometry, mainMaterial);
    group.add(mainMesh);

    // Add decorative elements
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const x = Math.cos(angle) * 5;
      const z = Math.sin(angle) * 5;

      const decorGeometry = new THREE.BoxGeometry(0.8, 3, 0.8);
      const decorMaterial = new THREE.MeshPhysicalMaterial({
        color: 0xffdd59,
        metalness: 0.8,
        roughness: 0.2
      });
      const decorMesh = new THREE.Mesh(decorGeometry, decorMaterial);
      decorMesh.position.set(x, 1.5, z);
      group.add(decorMesh);

      // Top spheres
      const sphereGeometry = new THREE.SphereGeometry(0.5, 16, 16);
      const sphereMaterial = new THREE.MeshPhysicalMaterial({
        color: 0xff6b6b,
        metalness: 0.9,
        roughness: 0.1,
        emissive: 0x330000,
        emissiveIntensity: 0.2
      });
      const sphereMesh = new THREE.Mesh(sphereGeometry, sphereMaterial);
      sphereMesh.position.set(x, 3.5, z);
      group.add(sphereMesh);
    }

    return group;
  };

  return <div ref={mountRef} className="three-scene" />;
};

export default ThreeScene;