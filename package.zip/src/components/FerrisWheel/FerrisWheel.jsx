import React, { useRef, useEffect, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

function FerrisWheel() {
  const groupRef = useRef();
  const { scene } = useGLTF('/ferris_final.glb');
  const cylinderRef = useRef();
  const cabins = useRef([]);
  const inverseQuat = useMemo(() => new THREE.Quaternion(), []);
  const textureLoader = useMemo(() => new THREE.TextureLoader(), []);

  const planeMeshes = useRef([]);
  const raycaster = useRef(new THREE.Raycaster());
  const mouse = useRef(new THREE.Vector2());
  const { camera, gl } = useThree();

  // Product links
  const links = useMemo(() => [
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',
    '/products/',

  ], []);

  useEffect(() => {
    if (!scene) return;

    // Clear previous references
    cabins.current = [];
    planeMeshes.current = [];

    // Clone scene to avoid modifying original
    const clonedScene = scene.clone();
    
    // Clear any existing children from group
    if (groupRef.current) {
      while (groupRef.current.children.length > 0) {
        groupRef.current.remove(groupRef.current.children[0]);
      }
    }

    cylinderRef.current = clonedScene.getObjectByName('Cylinder');

    for (let i = 1; i <= 10; i++) {
      const index = i.toString().padStart(3, '0');

      // Cabins
      const cabin = clonedScene.getObjectByName(`v${index}`);
      if (cabin) cabins.current.push(cabin);

      // Product image planes
      const plane = clonedScene.getObjectByName(`Plane${index}`);
      if (plane) {
        // Load texture with error handling
        const texture = textureLoader.load(
          `/p${i}.jpg`,
          undefined,
          undefined,
          (error) => {
            console.warn(`Failed to load texture p${i}.jpg:`, error);
          }
        );
        
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.repeat.x = -1;
        texture.offset.x = 1;
        texture.minFilter = THREE.LinearFilter;
        texture.magFilter = THREE.LinearFilter;

        plane.material = new THREE.MeshBasicMaterial({
          map: texture,
          transparent: false,
          opacity: 1,
          depthTest: true,
          depthWrite: true,
          side: THREE.DoubleSide,
        });

        // Rotate 180 degrees
        plane.rotation.y = Math.PI;

        // Add to clickable list
        plane.userData.link = links[i - 1];
        planeMeshes.current.push(plane);
      }
    }

    if (groupRef.current && clonedScene) {
      groupRef.current.add(clonedScene);
    }

    return () => {
      // Cleanup
      if (groupRef.current && clonedScene) {
        groupRef.current.remove(clonedScene);
      }
    };
  }, [scene, textureLoader, links]);

  useEffect(() => {
    const handleClick = (event) => {
      if (!gl.domElement) return;
      
      const rect = gl.domElement.getBoundingClientRect();

      // Mouse position in normalized device coordinates
      mouse.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.current.setFromCamera(mouse.current, camera);

      const intersects = raycaster.current.intersectObjects(
        planeMeshes.current,
        false
      );

      if (intersects.length > 0) {
        const clickedPlane = intersects[0].object;
        const url = clickedPlane.userData.link;
        if (url) {
          window.location.href = url;
        }
      }
    };

    // Pointer cursor on hover
    const handlePointerMove = (event) => {
      if (!gl.domElement) return;
      
      const rect = gl.domElement.getBoundingClientRect();
      mouse.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      
      raycaster.current.setFromCamera(mouse.current, camera);
      const intersects = raycaster.current.intersectObjects(planeMeshes.current, false);
      
      if (gl.domElement) {
        gl.domElement.style.cursor = intersects.length > 0 ? 'pointer' : 'default';
      }
    };

    if (gl.domElement) {
      gl.domElement.addEventListener('click', handleClick);
      gl.domElement.addEventListener('pointermove', handlePointerMove);
    }

    return () => {
      if (gl.domElement) {
        gl.domElement.removeEventListener('click', handleClick);
        gl.domElement.removeEventListener('pointermove', handlePointerMove);
      }
    };
  }, [camera, gl]);

  useFrame(() => {
    if (!cylinderRef.current) return;

    // Rotate the main cylinder
    cylinderRef.current.rotation.y -= 0.003;

    // Keep cabins upright
    cylinderRef.current.getWorldQuaternion(inverseQuat);
    inverseQuat.invert();

    cabins.current.forEach((cabin) => {
      if (cabin) {
        cabin.quaternion.copy(inverseQuat);
      }
    });
  });

  return <group ref={groupRef} position={[-1.2, 0.1, 0]} />;
}

// Preload the GLB file
useGLTF.preload('/ferris6.glb');

export default FerrisWheel;